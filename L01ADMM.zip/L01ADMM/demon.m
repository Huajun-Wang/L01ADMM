clear all; clc; close all;
addpath(genpath(pwd));
load Austrain
        X    = normalization(X,2);
        y    = Y;  
      [M,n]  = size(X);    y(y~=1)= -1;       
          X  = normalization(X,2); % normalize the data
 
% randomly split the data into training and testing data
m  = ceil(0.9*M);  mt = M-m;       I  = randperm(M);
Tt = I(1:mt);      tX = X(Tt,:);   ty = y(Tt);   % testing  data 
T  = I(1+mt:end);  X  = X(T,:);    y  = y(T,:);  % training data


pars.sigma = 1;
pars.C     = 1;

out        = L01ADMM(X,y,pars); 
wb         = out.wb;


fprintf('Support Vector:        %d\n',out.nsv);
fprintf('Training Accuracy:     %6.4f\n', accuracy(X,y,wb)) 
fprintf('Testing  Accuracy:     %6.4f\n', accuracy(tX,ty,wb));
fprintf('Training Time:         %5.3fsec\n',out.time);

