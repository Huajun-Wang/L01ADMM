clear all; clc; close all;
addpath(genpath(pwd));

type  = 2;
switch type
case 1; m0   = 2e3;
 [X,y,tX,ty] = randomData('2D',m0,2,0);  
case 2; load Austrain
        X    = normalization(X,2);
        y    = Y;  
      [M,n]  = size(X);    y(y~=1)= -1;       
          X  = normalization(X,2); % normalize the data
 
% randomly split the data into training and testing data
m  = ceil(0.9*M);  mt = M-m;       I  = randperm(M);
Tt = I(1:mt);      tX = X(Tt,:);   ty = y(Tt);   % testing  data 
T  = I(1+mt:end);  X  = X(T,:);    y  = y(T,:);  % training data
end

pars.sigma = 1;
pars.C     = 1;
out        = L01ADMM(X,y,pars); 
wb         = out.wb;


fprintf('Support Vector:        %d\n',out.nsv);
fprintf('Training Accuracy:     %6.4f\n', accuracy(X,y,wb)) 
if type == 1
fprintf('Testing  Accuracy:     %6.4f\n', accuracy(tX,ty,wb));
end
fprintf('Training Time:         %5.3fsec\n',out.time);

