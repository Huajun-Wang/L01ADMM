clear all; clc; close all;
addpath(genpath(pwd));

m           = 1e4; 
r           = 0;  % noise
[X,y,Xt,yt] = randomData(m,r);
fprintf(' ------------------------------------------------------------------------\n');
fprintf('      C      sigma     Iter      ACC       tACC       NSV        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -7:1:7
    pars.C     = 2^i;
    for  j     = -7:1:7
    pars.sigma = sqrt(2)^j;
    out        = L01ADMM(X,y,pars); 
    wb         = out.wb;
    if out.flag==2  
       tACC    = accuracy(Xt,yt,wb);  
       fprintf(' | %5.2f  |  %5.2f  |  %3d  |  %6.4f  |  %6.4f  |  %4d  |  %5.3fsec  |\n',...
       pars.C, pars.sigma, out.iter, out.acc,  tACC,out.nsv,out.time);
    end
    end
end 

