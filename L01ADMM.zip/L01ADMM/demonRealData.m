clear all; clc; close all;
addpath(genpath(pwd));

load Austrain
X      = normalization(X,2);
y      = Y;  y(y~=1)= -1;  
[M,n]  = size(X);         
X      = normalization(X,2); % normalize the data
 
% randomly split the data into training and testing data
m  = ceil(0.9*M);  mt = M-m;       I  = randperm(M);
Tt = I(1:mt);      Xt = X(Tt,:);   yt = y(Tt);   % testing  data 
T  = I(1+mt:end);  X  = X(T,:);    y  = y(T,:);  % training data
 

fprintf(' ------------------------------------------------------------------------\n');
fprintf('      C      sigma     Iter      ACC       tACC       NSV        TIME\n');
fprintf(' ------------------------------------------------------------------------\n');

for i          = -7:1:7
    pars.C     = 2^i;
    for  j     = -7:1:7
    pars.sigma = sqrt(2)^j;
    out        = L01ADMM(X,y,pars); 
    wb         = out.wb;
    if out.flag==1 
       tACC    = accuracy(Xt,yt,wb);  
       fprintf(' | %5.2f  |  %5.2f  |  %3d  |  %6.4f  |  %6.4f  |  %4d  |  %5.3fsec  |\n',...
       pars.C, pars.sigma, out.iter, out.acc,  tACC,out.nsv,out.time);
    end
    end
end 

