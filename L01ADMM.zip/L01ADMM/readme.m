

This source code is programmed based on the algorithm described in:

H.J. Wang, Y.H. Shao, S.L. Zhou, C. Zhang and N.H. Xiu, Support Vector Machine Classifier via  L_{0/1}  Soft-Margin Loss,
arXiv:1912.07418, 2019

Please give credits to this paper if you use the code for your research.
